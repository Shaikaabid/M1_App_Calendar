Sum = 4.000+i6.000
Difference = -2.000-i2.000
Product = -5.000+i10.000
Division = 0.440+i0.080
